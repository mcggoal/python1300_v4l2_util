#if !defined(S_RECORD_H)
#define S_RECORD_H

int s_record_to_bin(char *file_buffer, unsigned char *flash_buffer,
		    int file_size, int flash_size);

#endif /* S_RECORD_H */
