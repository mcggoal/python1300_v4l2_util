#ifndef __linux_compiler_h
#define __linux_compiler_h

#define __user

#endif
